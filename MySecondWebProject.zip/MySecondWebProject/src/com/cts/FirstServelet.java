package com.cts;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/FirstServelet")
public class FirstServelet extends HttpServlet {
	PrintWriter pw = null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		pw = response.getWriter();
		pw.println("<!DOCTYPE html>\r\n"+
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<title>Welcome</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"	<h2>Check a number</h2>\r\n" + 
				"	\r\n" + 
				"	<form action=\"SecondServlet\">\r\n" + 
				"	Enter Number : <input type=\"text\" name=\"number1\" placeholder=\"enter a number\"/>\r\n" + 
				"		<input type=\"submit\" value=\"check\"/>\r\n" + 
				"	</form>	\r\n" + 
				"</body>\r\n" + 
				"</html>"
				);
		String positivemsg = (String)request.getAttribute("positive") ;
		String negativemsg = (String)request.getAttribute("negative") ;
		pw.println(positivemsg!=null?positivemsg:"");
		pw.println(negativemsg!=null?negativemsg:"");
	}
}
