package com.cts;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Product")
public class Product extends HttpServlet {
	PrintWriter pw = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		pw = response.getWriter();
		pw.println("<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<title>Insert title here</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"	<h1 align=\"center\">Choose a product</h1>\r\n" + 
				"	<a href=\"ProductInfo?Name=Sport Shoe&price=400\"><img src=\"resources/Images/shoe.jpg\" height=\"300px\" width=\"300px\"/></a>\r\n" + 
				"	<a href=\"ProductInfo?Name=Watch&price=1000\"><img src=\"resorces/Images/watch.png\" height=\"300px\" width=\"300px\"/></a>\r\n" + 
				"	<a href=\"ProductInfo?Name=Bag&price=600\"><img src=\"resorces/Images/bag.png\" height=\"300px\" width=\"300px\"/></a>\r\n" + 
				"</body>\r\n" + 
				"</html>");
		String name = (String)request.getAttribute("name") ;
		int price = (Integer)request.getAttribute("price") ;
		pw.println(name!=null?name:"");
		pw.println(price!=0?price:"");
	}
}
