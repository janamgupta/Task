package com.cts.pms.controller;

import java.sql.SQLException;
import java.util.List;


public class ProductService {

	private ProductDao edao=null;
	
	public int addProduct(Product pdt) throws SQLException{
		edao=new ProductDao();
		//validation logic to be done here
		return edao.addProduct(pdt);
	}
	
	public Product getProductById(int pdtId) throws SQLException{
		edao=new ProductDao();
		return edao.getProductById(pdtId);
	}
	
	public List<Product> getAllProduct() throws SQLException{
		edao=new ProductDao();
		return edao.getAllProducts();
	}	
}
