package com.cts.pms.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("*.do") // helps avoiding multiple controller for single module
// like admin, product etc...
// we can't write add, delete etc logic in single post or get method
public class ProductController extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	ProductService empServ=null;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// logic here
		String path=req.getServletPath();
		System.out.println(path);
		String result=null;
		RequestDispatcher rd=null;
		switch(path){		
		case "/addProduct.do":
			empServ=new ProductService();
			//System.out.println("enter product info:");
			Product pdt=new Product();
			

			//	addProduct(prod);
			break;
				
		case "/getById.do":
			String id=req.getParameter("pid");
			int searchId=Integer.parseInt(id);
			Product prod=null;
						try {
				prod = getById(searchId);
			} catch (SQLException e) {
				result ="getbyid.jsp";
				req.setAttribute("msg","problem occured :: "+e.getMessage());
				
			}
			System.out.println(prod);
			//navigate to getbyid.jsp
			result="getbyid.jsp";
			req.setAttribute("prodObj",prod);
			break;
			
		case "/getall.do":
			List<Product>allProd = new ArrayList<>();
			try {
				allProd = getAll();
			} catch (SQLException e) {
				result = "allprodresult.jsp";
				req.setAttribute("msg","Problem occured :: "+e.getMessage());
			}
			for(Product pro:allProd)
			{
				System.out.println(pro);
			}
			result = "allprodresult.jsp";
			req.setAttribute("allProd",allProd);
			break;
		case "/updateproduct.do":
			int uid = Integer.parseInt(req.getParameter("id"));
			Product uprod=null;
			try {
				uprod = getById(uid);
			} catch (SQLException e) {
				result = "updateform.jsp";
				req.setAttribute("msg","Problem occured :: "+e.getMessage());
			}
			result = "updateform.jsp";
			req.setAttribute("uprod", uprod);
			break;
		case "/editProduct.do":
			int eid = Integer.parseInt(req.getParameter("prodid"));
			String ename = req.getParameter("prodName");
			int eprice = Integer.parseInt(req.getParameter("price"));
			int equantity = Integer.parseInt(req.getParameter("Quantity"));
			Product eprod = new Product(eid, ename, equantity, eprice);
			ProductDao pd = new ProductDao();
			pd.updateProduct(eprod);
			List<Product>eProd = new ArrayList<>();
			try {
				eProd = getAll();
			} catch (SQLException e) {
				result = "allprodresult.jsp";
				req.setAttribute("msg","Problem occured :: "+e.getMessage());
			}
			result = "allprodresult.jsp";
			req.setAttribute("allProd",eProd);
			break;
		case "/deleteproduct.do":
			int did = Integer.parseInt(req.getParameter("id"));
			ProductDao dd = new ProductDao();
			List<Product>dProd = new ArrayList<>();
			try {
				dd.deleteProduct(did);
				dProd = getAll();
			} catch (SQLException e) {
				result = "allprodresult.jsp";
				req.setAttribute("msg","Problem occured :: "+e.getMessage());
			}
			result = "allprodresult.jsp";
			req.setAttribute("allProd",dProd);
			break;
		default:
			break;
		}
		rd=req.getRequestDispatcher(result);
		rd.forward(req,resp);
	}

	private int addProduct(Product prod) {
		
		return 0;
	}

	private Product getById(int searchId) throws SQLException {
		empServ=new ProductService();
		Product p=empServ.getProductById(searchId);
		return p;
	}

	private List<Product> getAll() throws SQLException {
		empServ = new ProductService();
		List<Product>prodData = empServ.getAllProduct();
		return prodData;
	}
}
