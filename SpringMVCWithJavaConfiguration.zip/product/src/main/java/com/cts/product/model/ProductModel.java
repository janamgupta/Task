package com.cts.product.model;

import org.springframework.stereotype.Repository;
@Repository
public class ProductModel {
	
	private Integer pId;

	private String pName;

	private Integer pQuantity;

	private Float pPrice;

	private Integer pTax;
	
	public ProductModel() {
		
	}

	public ProductModel(Integer pId, String pName, Integer pQuantity, Float pPrice, Integer pTax) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.pQuantity = pQuantity;
		this.pPrice = pPrice;
		this.pTax = pTax;
	}


	public Integer getpId() {
		return pId;
	}

	public void setpId(Integer pId) {
		this.pId = pId;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public Integer getpQuantity() {
		return pQuantity;
	}

	public void setpQuantity(Integer pQuantity) {
		this.pQuantity = pQuantity;
	}

	public Float getpPrice() {
		return pPrice;
	}

	public void setpPrice(Float pPrice) {
		this.pPrice = pPrice;
	}

	public Integer getpTax() {
		return pTax;
	}

	public void setpTax(Integer pTax) {
		this.pTax = pTax;
	}
}
