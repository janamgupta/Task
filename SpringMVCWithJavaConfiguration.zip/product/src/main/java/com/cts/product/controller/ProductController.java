package com.cts.product.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cts.product.model.ProductModel;
import com.cts.product.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductModel product;
	@Autowired
	ProductService prodService;
	@GetMapping("/")
	public String gotohome(Model m) {
		m.addAttribute("product",product);
		return("home");
	}
	
	@PostMapping("process.do")
	public ModelAndView processproduct(@ModelAttribute("product") ProductModel product) {
		String path=null;
		ModelAndView modelAndView = new ModelAndView();
		path="success";
		int pid = prodService.addproduct(product);
		modelAndView.addObject("msg","Stored successfully with "+pid+" !!!");
		modelAndView.setViewName(path);
		return modelAndView;
	}
}
