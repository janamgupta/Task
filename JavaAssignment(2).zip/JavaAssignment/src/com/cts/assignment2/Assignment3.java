package com.cts.assignment2;

import java.util.Arrays;
import java.util.Scanner;

public class Assignment3 {

	public static void main(String[] args) {
		
		int totalNumbers;
		int i;
		int numberarray[] = new int[20];
		Scanner input = new Scanner(System.in);
		
		System.out.println("How many number you want to enter:");
		totalNumbers = input.nextInt();
		
		System.out.println("Enter Number to add into array:");
		for(i = 0; i < totalNumbers; i++) {
			numberarray[i] = input.nextInt();
		}
		
		Arrays.sort(numberarray,0,totalNumbers);
		System.out.println("Maximum Number in Array is: "+numberarray[totalNumbers-1]);
		System.out.println("Minimum Number in Array is: "+numberarray[0]);
	}

}
