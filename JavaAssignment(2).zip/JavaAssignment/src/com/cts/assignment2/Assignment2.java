package com.cts.assignment2;

import java.util.Arrays;
import java.util.Scanner;

public class Assignment2 {

	public static void main(String[] args) {
		int totalNumbers;
		int i;
		float floatarray[] = new float[20];
		Scanner input = new Scanner(System.in);
		
		System.out.println("How many number you want to enter:");
		totalNumbers = input.nextInt();
		
		System.out.println("Enter float Numbers to add into array:");
		for(i = 0; i < totalNumbers; i++) {
			floatarray[i] = input.nextFloat();
		}
		
		Arrays.sort(floatarray,0,totalNumbers);
		System.out.println("Array after sorting:");
		for(i = 0; i < totalNumbers; i++) {
			System.out.println(floatarray[i]);
		}

	}

}
