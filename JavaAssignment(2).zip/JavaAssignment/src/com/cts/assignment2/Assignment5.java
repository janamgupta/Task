package com.cts.assignment2;

import java.awt.font.NumericShaper;
import java.util.Scanner;

public class Assignment5 {

	public static void main(String[] args) {
		int totalNumbers;
		int i;
		int numberarray[] = new int[20];
		Scanner input = new Scanner(System.in);
		
		System.out.println("How many number you want to enter:");
		totalNumbers = input.nextInt();
		
		System.out.println("Enter Number to add into array:");
		for(i = 0; i < totalNumbers; i++) {
			numberarray[i] = input.nextInt();
		}
		
		System.out.println("Enter position where you want to enter number:");
		int index = input.nextInt();
		if(index > numberarray.length) {
			System.out.println("Index does not exist");
		}
		else {
			System.out.println("Enter the number:");
			int number = input.nextInt();
			for(i = numberarray.length-1; i >= index; i--) {
				numberarray[i] = numberarray[i-1];
			}
			numberarray[index-1] = number;
		}
		for(i = 0; i < totalNumbers+1; i++) {
			System.out.println(numberarray[i]);
		}
	}
}

