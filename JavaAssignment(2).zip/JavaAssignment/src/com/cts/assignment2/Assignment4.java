package com.cts.assignment2;

import java.util.Arrays;
import java.util.Scanner;

public class Assignment4 {

	public static void main(String[] args) {
		int totalNumbers;
		int i;
		int numberarray[] = new int[20];
		Scanner input = new Scanner(System.in);
		
		System.out.println("How many number you want to enter:");
		totalNumbers = input.nextInt();
		
		System.out.println("Enter Number to add into array:");
		for(i = 0; i < totalNumbers; i++) {
			numberarray[i] = input.nextInt();
		}
		
		System.out.println("Enter position of number you want to remove:");
		int index = input.nextInt();
		if(index > totalNumbers) {
			System.out.println("Index does not exist");
		}
		else {
			for(i = index-1; i < totalNumbers; i++) {
				numberarray[i] = numberarray[i+1];
			}
		}
		for(i = 0; i < totalNumbers-1; i++) {
			System.out.println(numberarray[i]);
		}
	}

}
