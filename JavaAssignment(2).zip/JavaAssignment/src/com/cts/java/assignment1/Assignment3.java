package com.cts.java.assignment1;

import java.util.Scanner;

public class Assignment3 {
	public static void main(String args[]) {
		
		char choice;
		char wantToPlay;
		int score = 0;
		Scanner scan  = new Scanner(System.in);
		
		System.out.println("Do you want to play Y/N");
		wantToPlay = scan.next().charAt(0);
		
		if(wantToPlay == 'y' || wantToPlay == 'Y') {
			System.out.println("lets play!!!!!");
			System.out.println("ques 1. What is the result of 4*3/3? \n a. 6 \n b. 4 \n c. 6");
			System.out.print(">");
			choice = scan.next().charAt(0);
			if(choice != 'b') {
				System.out.println("Wrong Answer.");
			}else {
				System.out.println("That's correct.");
				score++;
			}
			
			System.out.println("ques 2. Is Java a pure object oriented programming? \n a. yes \n b. No");
			System.out.print(">");
			choice = scan.next().charAt(0);
			if(choice != 'b') {
				System.out.println("Wrong Answer");
			}else {
				System.out.println("That's correct.");
				score++;
			}
			
			System.out.println("ques 3. Who recently achieved Quantum Supermacy? \n a. IBM \n b. Google \n c. Microsoft");
			System.out.print(">");
			choice = scan.next().charAt(0);
			if(choice != 'b') {
				System.out.println("Wrong Answer");
			}else {
				System.out.println("That's correct.");
				score++;
			}
			System.out.println("Your Score is: "+score);
		}else {
			System.out.println("okay will play next time.");
		}
	}
}
