package com.cts.java.assignment1;

import java.util.Scanner;

public class Assignment2 {

	public static void main(String[] args) {
	
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter your Name: ");
	
		while(!input.hasNext("^[A-Za-z]+$@#")){
			System.out.println("Required name does not match try again:");
			input.next();
		}
		String name = input.next();
		
		System.out.println("Enter your Year of Graduation: ");
		
		while(!input.hasNextInt()) {
			System.out.println("Entered Year is not Corret try again!!!");
			input.nextInt();
		}
		int graduationYear = input.nextInt();
		
		System.out.println("My name is "+name+" and i'll graduate in "+graduationYear);
		
		input.close();
	}
}
