package com.cts.java.assignment1;

import java.util.Scanner;

public class Assignment1 {

	public static void main(String[] args) {
		String name = new String();
		int graduation_year = 0;
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter your Name: ");
		name = scan.next();
		
		System.out.println("Enter your Year of Graduation: ");
		graduation_year = scan.nextInt();
		
		System.out.println("My name is "+name+" and i'll graduate in "+graduation_year);
	}

}
