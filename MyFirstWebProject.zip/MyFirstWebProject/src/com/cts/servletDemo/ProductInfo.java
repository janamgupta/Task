package com.cts.servletDemo;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ProductInfo extends HttpServlet {
       private PrintWriter pw = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		pw = response.getWriter();
		String name = request.getParameter("Name");
		int Price = Integer.parseInt(request.getParameter("price"));
		pw.println(name);
		pw.println("Price : "+Price);
	}
}
