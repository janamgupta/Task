package com.cts.servletDemo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CheckNumber extends HttpServlet {
	
	private PrintWriter pw = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		pw = response.getWriter();
		int number = Integer.parseInt(request.getParameter("number1"));
		if(number < 0) {
			pw.println("Number is negative");
		}
		else
		{
			pw.println("Number is positive");
		}
	}
}
