package com.cts.crudwithspringboot;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Product;
import com.cts.service.IProductService;

@RestController
public class CrudController {
	
	@Autowired
	IProductService prodService;
	
	@RequestMapping("getAll")
	public List<Product> getAll(){
		
		return prodService.getall();
	}
	
	@RequestMapping("getById/{id}")
	public Optional<Product> getById(@PathVariable("id") Integer id) {
		
		return prodService.getById(id);
	}

	@RequestMapping(value = "addproduct", method = RequestMethod.POST, produces = "application/json")
	public Integer addProduct(@RequestBody Product product)
	{
		Integer prodId = prodService.addProduct(product);
		return prodId;
	}
	
	@RequestMapping("deleteproduct/{id}")
	public void deleteprod(@PathVariable("id") Integer id) {
		
		prodService.deleteById(id);
	}
}
