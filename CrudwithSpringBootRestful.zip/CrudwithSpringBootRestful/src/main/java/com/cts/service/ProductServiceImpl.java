package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.IProductDao;
import com.cts.model.Product;
@Service
public class ProductServiceImpl implements IProductService {
	@Autowired
	IProductDao prodDao;
	@Override
	public List<Product> getall() {
		
		return prodDao.findAll();
	}

	@Override
	public Optional<Product> getById(Integer id) {
		
		return prodDao.findById(id);
	}

	/*
	 * @Override public Integer updateProduct(Integer id) { Product product =
	 * (Product)getById(id); return prodDao.save(product); }
	 */

	@Override
	public void deleteById(Integer id) {
		prodDao.deleteById(id);
	}

	@Override
	public Integer addProduct(Product product) {
		Product savedProduct = prodDao.save(product);
		return savedProduct.getProdId();
	}

}
