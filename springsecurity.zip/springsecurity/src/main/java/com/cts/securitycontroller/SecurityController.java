package com.cts.securitycontroller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class SecurityController {
	@RequestMapping(value="/", method = RequestMethod.GET)
    public String visitHomePage() {
        return "Home";
    }

    @RequestMapping(value="/admin", method = RequestMethod.GET)
    public String visitAdministratorPage(ModelMap modelObj) {       
        modelObj.addAttribute("welcomeTitle", "Admministrator Control Panel");
        modelObj.addAttribute("messageObj", "This Page Demonstrates How To Use Spring Security!");
        return "Admin";
    }
    
    @RequestMapping(value="/user", method = RequestMethod.GET)
    public String visitUserPage(ModelMap modelObj) {       
        modelObj.addAttribute("welcomeTitle", "User Control Panel");
        modelObj.addAttribute("messageObj", "This Page Demonstrates How To Use Spring Security!");
        return "User";
    }
}
