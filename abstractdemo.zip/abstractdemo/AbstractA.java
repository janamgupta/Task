package com.cts.abstractdemo;

public abstract class AbstractA {
	public abstract void abstractA();
	public void methodA1() {
		System.out.println("Method a");
	}
}
