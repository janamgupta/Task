package com.cts.abstractdemo;

public class AbstractDemo extends AbstractB{

	@Override
	public void methodB() {
		// TODO Auto-generated method stub
		System.out.println("override B");
	}

	@Override
	public void abstractA() {
		// TODO Auto-generated method stub
		System.out.println("override A");
	}

}
