package com.cts.abstractdemo;

public abstract class AbstractB extends AbstractA {
	public abstract void methodB();
	public void methodB1() {
		System.out.println("Method of B");
	}
}
