package com.cts.abstractdemo;

public class AbstractDemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractDemo ad = new AbstractDemo();
		ad.methodA1();
		ad.methodB();
		ad.methodB1();
		ad.abstractA();
	}

}
