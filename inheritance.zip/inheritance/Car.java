package com.cts.inheritance;

public class Car extends Vehicle{
	public Car(int noOfWheels, int noOfPassenger) {
		super(noOfWheels, noOfPassenger);
	}
	public void carMethod() {
		System.out.println("car Method");
	}
	
	public void runVehicle() {
		System.out.println("Car running");
	}
	
	public void stopVehicle() {
		System.out.println("Car stopping");
	}
}
