/*Author: Janam Gupta
 *Description: This is piece of code shows example of inheritance.
 *Created on : 12/01/2020
 * */
package com.cts.inheritance;

public class TestInheritance {

	public static void main(String[] args) {

		Bike bike = new Bike(2, 2);
		Car car = new Car(4, 4);
		bike.runVehicle();
		bike.stopVehicle();
		bike.bikeMethod();
		car.runVehicle();
		car.stopVehicle();
		car.carMethod();
		System.out.println("The car has "+car.noOfWheels+" wheels and can accomodate "+car.noOfPassengers+" passenger");
		System.out.println("The bike has "+bike.noOfWheels+" wheels and can accomodate "+bike.noOfPassengers+" passenger");
	}

}
