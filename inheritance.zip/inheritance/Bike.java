package com.cts.inheritance;

public class Bike extends Vehicle{
	public Bike(int noOfWheels, int noOfPassenger) {
		super(noOfWheels, noOfPassenger);
	}
	public void bikeMethod() {
		System.out.println("BIke Method");
	}
	
	public void runVehicle() {
		System.out.println("Bike running");
	}
	
	public void stopVehicle() {
		System.out.println("Bike stopping");
	}
}
