package com.cts.inheritance;

public class Vehicle {
	public int noOfWheels;
	public int noOfPassengers;
	public Vehicle() {
		
	}
	
	public Vehicle(int noOfWheel, int noOfPassengers) {
		this.noOfWheels = noOfWheel;
		this.noOfPassengers = noOfPassengers;
	}
	
	public void runVehicle() {
		System.out.println("Driving");
	}
	
	public void stopVehicle() {
		System.out.println("stopping");
	}
}
