package com.cts.controller;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Product;

@RestController
public class Controller {
	
	List<Product> l = new ArrayList<Product>();
	Map<Integer,Product> m = new HashMap<Integer, Product>();
	
	public Controller() {
		l.add(new Product(1001, "tv", 5, 2000.90f));
		l.add(new Product(1002, "washing machine", 5, 4000.90f));
		l.add(new Product(1003, "radio", 34, 200.90f));
		l.add(new Product(1004, "toy", 6, 700.90f));
		m.put(1001, new Product(1001, "tv", 5, 2000.90f));
		m.put(1002, new Product(1002, "tv", 5, 2000.90f));
		m.put(1003, new Product(1003, "tv", 5, 2000.90f));
		m.put(1004, new Product(1004, "tv", 5, 2000.90f));
	}

	@RequestMapping("/data")
	public List<Product> method1() {
		return l;
	}
	
	@RequestMapping("/jsondata")
	public Map<Integer, Product> method2() {
		return m;
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Product searchproduct(@PathVariable("id") Integer prodId) {
		return m.get(prodId);
	}
}
