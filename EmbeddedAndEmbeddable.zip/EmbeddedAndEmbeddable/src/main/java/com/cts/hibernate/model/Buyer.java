package com.cts.hibernate.model;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Buyer implements Serializable{
	@Id
	@GeneratedValue
	private int buyerID;
	@Embedded
	@AttributeOverride(column = @Column, name = "buyerName")
	private Name name;
	public Buyer() {
		// TODO Auto-generated constructor stub
	}
	public int getBuyerID() {
		return buyerID;
	}
	public void setBuyerID(int buyerID) {
		this.buyerID = buyerID;
	}
	public Name getName() {
		return name;
	}
	public void setName(Name name) {
		this.name = name;
	}
	public Buyer( Name name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Buyer [buyerID=" + buyerID + ", name=" + name + "]";
	}
	
}
