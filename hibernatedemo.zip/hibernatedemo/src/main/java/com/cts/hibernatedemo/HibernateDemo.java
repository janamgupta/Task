package com.cts.hibernatedemo;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.model.Product;

public class HibernateDemo {

	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure();
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();//managed state
		//Insert into database
		/*Product prod = new Product(1009,"Washing Machine",30 ,4000.89f);
		session.beginTransaction();
		Serializable serializable = session.save(prod);
		prod.setProdprice(5000.89f);
		session.getTransaction().commit();
		System.out.println(serializable);*/
		
		//retrieve from database                                
		/*Product prod = (Product)session.get(Product.class,1009);
		System.out.println(prod);
		session.close();*/
		
		
			
	}

}
