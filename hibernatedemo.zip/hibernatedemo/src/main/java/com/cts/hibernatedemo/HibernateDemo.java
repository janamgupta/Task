/*Author: Janam Gupta
 *Date Created: 04-02-2020
 *Description: Hibernate basic
 * */
package com.cts.hibernatedemo;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.Product;

public class HibernateDemo {

	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure();
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		//create and add data
		Product prod = new Product(1003, "Tv", 30, 4000.89f);
		session.beginTransaction();
		Serializable serializable = session.save(prod);
		session.getTransaction().commit();
		session.close();
		
		//retrieve from database and updating
		/*session.beginTransaction();
		Product prod = (Product)session.get(Product.class,1003);
		System.out.println(prod);
		prod.setProdPrice(3000.78f);
		prod.setProdQuantity(50);
		session.update(prod);
		session.getTransaction().commit();
		session.close();*/
		
		//delete from database
		/*session.beginTransaction();
		Product prod = (Product)session.get(Product.class,1003);
		session.delete(prod);
		session.getTransaction().commit();
		session.close();*/
		
		//session.evict(object); detach the object from persistent context
		//session.flush();push update explicitly
	}

}
