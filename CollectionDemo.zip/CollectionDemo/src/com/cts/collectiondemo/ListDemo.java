package com.cts.collectiondemo;

import java.util.ArrayList;
import java.util.List;

public class ListDemo {

	public static void main(String[] args) {
	
		List employee = new ArrayList();
		employee.add("Amit");
		employee.add(20);
		employee.add("developer");
		
		System.out.println("My name is "+employee.get(0)+" my age is "+employee.get(1)+" I am a "+employee.get(2)+" .");
		
		//Generic list
		List<String>employeeName = new ArrayList();
		employeeName.add("Amit");
		employeeName.add("Suresh");
		employeeName.add("Rajesh");
		
		for (String name : employeeName) {
			System.out.println(name);
		}
		
		employeeName.remove(2);
		
		System.out.println("After Removal of data");
		for (String name : employeeName) {
			System.out.println(name);
		}
	}

}
