/*Author: Janam Gupta
 *Description: This is piece of code contain product information and several operations.
 *Created on : 12/01/2020
 *Version :1.0
 */
package com.cts.miniproject;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Product {
	private int productId;
	private String productName;
	private double price;
	private int quantity;
	private String category;
	private String description;
	
	static Map<Integer,Product> productData = new HashMap<Integer,Product>();
	
	public Product() {
		
	}
	
	public Product(int productId, String productName, double price, int quantity, String category, String description) {
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.quantity = quantity;
		this.category = category;
		this.description = description;
	}

	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	public int getProductId() {
		return productId;
	}
	
	//to add product
	public static void addProduct(Product pd) {
		productData.put(pd.getProductId(), pd);
		System.out.println("Product added successfully!!!!");
	}
	
	//to search product by productid
	public static void searchById() {
		Scanner scan = new Scanner(System.in);
		Set<Integer> productKey = productData.keySet();
		for(Integer key : productKey) {
			System.out.println("\nEnter the Id of the product you want to get details: ");
			Integer productId = (Integer)scan.nextInt();
			System.out.println("The required product details are:\n"+productData.get(productId));
		}
		System.out.println("print by id");
	}
	
	//to show all the data
	public static void getAllData() {
		Collection<Product> productDetail = productData.values();
		System.out.println(productDetail);
	}

	@Override
	public String toString() {
		return "The Products are \n productId :" + productId + ", productName: " + productName + ", price: " + price + ", quantity:"
				+ quantity + ", category: " + category + ", Description: " + description + "\n";
	}
}
