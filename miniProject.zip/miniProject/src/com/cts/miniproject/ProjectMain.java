/*Author: Janam Gupta
 *Description: This is piece of code contain Main Method.
 *Created on : 12/01/2020
 *Version :1.0
 */
package com.cts.miniproject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class ProjectMain {
	public static void main(String[] args) {
		int choice = 0;
		int categoryChoice = 1;
		char operation = 'y';
		Scanner scan = new Scanner(System.in);
		Random random = new Random();
		List<String> category = new ArrayList<String>();
		category.add("Tv");
		category.add("Refrigerator");
		category.add("Washing Machine");
		category.add("Microwave Oven");
		System.out.println("Welcome Choose an Opertation from below List: ");
		while(operation == 'y' || operation == 'Y') {
			System.out.println(operation);
			System.out.println("1. Enter '1' to Add Product to list \n"
					+ "2. Enter '2' to Search Product by Id "
					+ "\n3. Enter '3' to Get All Data ");
		
			choice = scan.nextInt();
			switch(choice) {
			case 1 :
				Product pd = new Product();
				
				pd.setProductId(1000 + random.nextInt(10));
				
				System.out.println("Enter Product Name:");
				pd.setProductName(scan.next());
				
				System.out.println("Enter Product Quantity:");
				pd.setQuantity(scan.nextInt());
				
				System.out.println("Enter Product Price:");
				pd.setPrice(scan.nextInt());;
				
				System.out.println("Enter Product Description:");
				pd.setDescription(scan.next());;
				
				System.out.println("Choose Product Category:");
				for (String string : category) {
					System.out.println(string);
				}
				System.out.print("Enter your choice");
				categoryChoice = scan.nextInt();
				switch(categoryChoice) {
				case 1 :
					pd.setCategory(category.get(0));
					break;
				case 2 :
					pd.setCategory(category.get(1));
					break;
				case 3 :
					pd.setCategory(category.get(2));
					break;
				case 4 :
					pd.setCategory(category.get(3));
					break;
				default:
					System.out.println("choose correct product key");
					break;
				}
				Product.addProduct(pd);
				break;
			case 2 :
				Product.getAllData();
				break;
			case 3 :
				Product.getAllData();				
				break;
			default :
				System.out.println("Enter Correct Choice");
				break;
			}
		System.out.println("press 'N' to stop or 'Y' to continue");
		operation = scan.next().charAt(0);
		}
	}
}
