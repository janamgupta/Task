/*Author: Janam gupta
 * Date: 08/01/2020
 * Description: Count the no of object created
 * */
package com.cts.day2;

public class ObjectCountInheritance {
	public static void main(String[] args) {
		Base b = new Base();
		Derived d = new Derived();
		Base b1 = new Base();
		Derived d1 = new Derived();
		System.out.println(b1.count);
	}
}