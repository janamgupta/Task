/*Author: Janam gupta
 * Date: 08/01/2020
 * Description: Count the no of object created
 * */
package com.cts.day2;

public class Base {
	static int count = 0;
	public Base() {
		count++;
	}
}
