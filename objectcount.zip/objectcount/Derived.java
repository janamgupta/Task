/*Author: Janam gupta
 * Date: 08/01/2020
 * Description: Count the no of object created
 * */
package com.cts.day2;

public class Derived extends Base{
	
}
