/*Author: Janam gupta
 * Date: 08/01/2020
 * Description: Interface demo
 * */
package com.cts.interfacedemo;

public class InterfaceMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfacedemoTest demo = new InterfacedemoTest();
		demo.m1();
		demo.m2();
		demo.m3();
	}

}
