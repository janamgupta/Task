package com.cts.interfacedemo;

public interface Interface3 {
	public abstract void m3();
}
