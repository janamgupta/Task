package com.cts.interfacedemo;

public interface Interface1 extends Interface2, Interface3 {
	public abstract void m1();
}
