package com.cts.interfacedemo;

public interface Interface2 {
	public abstract void m2();
}
