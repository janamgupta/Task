package com.cts.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cts.model.Product;
import com.cts.util.Dbutil;
import com.cts.util.IQueryMapper;

public class ProductDao {

	
	public int addProduct(Product prod) throws SQLException {
		Connection con = Dbutil.getConnectionForDb();
		PreparedStatement pst = con.prepareStatement(IQueryMapper.ADD);
		pst.setInt(1, prod.getProdId());
		pst.setString(2, prod.getProdName());
		pst.setDouble(3,prod.getProdPrice());
		pst.setInt(4,prod.getQuantity());
		
		int prodId = 0;
		prodId = pst.executeUpdate();
		if(prodId>0) {
			prodId = prod.getProdId();
		}
		return prodId;
	}
}
