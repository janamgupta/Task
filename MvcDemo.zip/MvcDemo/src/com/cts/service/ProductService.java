package com.cts.service;

import java.sql.Connection;
import java.sql.SQLException;

import com.cts.Dao.ProductDao;
import com.cts.model.Product;
import com.cts.util.Dbutil;

public class ProductService {
	
	private ProductDao pdao = null;
	public int addProduct(Product prod) throws SQLException {
		pdao = new ProductDao();
		
		return pdao.addProduct(prod);
	}
}
