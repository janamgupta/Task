package com.cts.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.model.Product;
import com.cts.service.ProductService;

@WebServlet("/ProductController.do")
public class ProductController extends HttpServlet {
	
	private ProductService pServ= null;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("pName");
		Double price = Double.parseDouble(req.getParameter("price"));
		int qun = Integer.parseInt(req.getParameter("qty"));
		int id = new Random().nextInt(1000);
		
		Product prod = new Product();
		prod.setProdName(name);
		prod.setProdPrice(price);
		prod.setQuantity(qun);
		prod.setProdId(id);
		pServ = new ProductService();
		String path = null;
		String msg = null;
		RequestDispatcher rd = null;
		try {
			int prodId = pServ.addProduct(prod);
			path = "result";
			rd = req.getRequestDispatcher(path);
			req.setAttribute("msg",prodId+"Successfully stored!!!");
			rd.forward(req, resp);
		} catch (SQLException e) {
			path="result";
			msg="data not stored:: "+e.getMessage();
			rd = req.getRequestDispatcher(path);
		   req.setAttribute("msg", msg);
		   rd.forward(req, resp);
		}
	}
}
