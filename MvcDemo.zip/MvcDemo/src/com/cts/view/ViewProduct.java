/*Author: Janam Gupta
 *Description: MVC Demo
 *Created on : 12/01/2020
 */
package com.cts.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.tagplugins.jstl.core.Out;

@WebServlet("/result")
public class ViewProduct extends HttpServlet {
	
	PrintWriter pw = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String msg = (String)request.getAttribute("msg");
		pw = response.getWriter();
		pw.println("<html><head><title>my page</title></head>");
		pw.println("<body>");
		pw.println("<h1>"+msg+"</h1>");
		pw.println("</body>");
		pw.println("</html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		doGet(request, response);
	}

}
