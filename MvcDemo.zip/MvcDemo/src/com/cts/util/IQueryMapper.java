package com.cts.util;

public class IQueryMapper {
	public static final String ADD = "INSERT INTO Productdata VALUES(?,?,?,?);";
}
