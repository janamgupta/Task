package com.cts.model;

public class Product {
	private String prodName;
	private int prodId;
	private double prodPrice;
	private int quantity;
	
	
	public Product(String prodName, int prodId, double prodPrice, int quantity) {
		super();
		this.prodName = prodName;
		this.prodId = prodId;
		this.prodPrice = prodPrice;
		this.quantity = quantity;
	}
	
	public Product() {}
	
	public String getProdName() {
		return prodName;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public double getProdPrice() {
		return prodPrice;
	}
	public void setProdPrice(double prodPrice) {
		this.prodPrice = prodPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getProdId() {
		return prodId;
	}
	
	
}
