package com.cts.streamdemo;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamCreation {
	
	public static void main(String args[]) {
			
		Stream<String> emptystream = Stream.empty();
		System.out.println(emptystream);//Create Empty Stream
		
		Stream<String> stream1 = Stream.of("d","e","f");//Create Stream using 'of' method.
		
		Collection<Integer>collection = Arrays.asList(1,2,3);
		Stream<Integer>stream2 = collection.stream();//Using any collection also we can create the stream.
		
		Stream stream3 = Stream.of(23,"e",40.0f,false);
		
		String arr[] = new String[] {"aa","ba","ca"};
		Stream<String> streamofarrayfull = Arrays.stream(arr);
		Stream<String> streampart = Arrays.stream(arr,0,2);
		
		emptystream = Arrays.asList("a","b","c").stream();
		System.out.println(emptystream);
		
		List<String> filledstream = emptystream.collect(Collectors.toList());
		for(String data:filledstream) {
			System.out.println(data);
		}
		
		stream1.forEach(s->System.out.println(s));
		
		stream2.forEach(s->System.out.println(s));
		
		stream3.forEach(s->System.out.println(s));
		
		streamofarrayfull.forEach(s->System.out.println(s));
		
		streampart.forEach(s->System.out.println(s));
	}
}
