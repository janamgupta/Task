package com.cts.streamdemo;

import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class StreamOfPrimitives {

	public static void main(String[] args) {
		
		IntStream intstream = IntStream.of(20,40,80);
		IntStream intstream2 = IntStream.range(5, 10);
		IntStream intstream3 = IntStream.concat(intstream, intstream2);
		
		
		intstream.peek(System.out::println);
		/*intstream2.peek(p->System.out.println(p)).count();*/
		intstream3.forEach(e->System.out.println("Stream C :"+e));
		
	}

}
