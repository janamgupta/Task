package com.cts.streamdemo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SumOfSalaryOnDesignation {
	public static void main(String args[]) {
		List<Employee> emp= new ArrayList<Employee>();
		emp.add(new Employee(1001,"amit","consultant",2598.56));
		emp.add(new Employee(1002,"sumit","consultant",2500.56));
		emp.add(new Employee(1003,"vijay","FSE",3000.78));
		emp.add(new Employee(1004,"ajay","FSE",4006.70));
		emp.add(new Employee(1005,"ravi","Manager",6000.78));
		
		System.out.println(emp.stream().collect(Collectors.groupingBy(Employee::getDesig,Collectors.summingDouble(Employee::getSalary))));
	}
}
