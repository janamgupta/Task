package com.cts.polymorphism;

public class Employee {
	public void employeeMethod() {
		System.out.println("Employee");
	}
}
