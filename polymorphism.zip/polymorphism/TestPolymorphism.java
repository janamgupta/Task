/*Author: Janam Gupta
 *Description: This is piece of code shows example of polymorphism.
 *Created on : 14/01/2020
 * */
package com.cts.polymorphism;

public class TestPolymorphism {

	public static void main(String[] args) {
		Employee e = null;
		e = new Employee();
		e.employeeMethod();
		
		e = new Admin();//Upward casting Done by compiler
		//it should be used when you want to use override method of base class which is employee method.
		e.employeeMethod();
		
		Admin ad = (Admin)e;//Downward Casting To use the featured method of Admin class.
		ad.adminMethod();
		
		e = new Manager();//upward casting
		e.employeeMethod();
		
		Manager mg = (Manager)e;//Downward Casting
		mg.managerMethod();
		
		//ad = (Admin)e;
		/*This line will throw error class cast exception 
		  because right now e has object of Manager which 
		  is of same level as of admin. */
		
		/*To Prevent class cast exception to occur 
		  we must first check whether it hold the 
		  instance of base class or not.*/
		
		if(e instanceof Manager) {
			mg = (Manager)e;
			mg.managerMethod();
		}
		else {
			if(e instanceof Admin) {
				ad = (Admin)e;
				ad.adminMethod();
			}
			else {
				e.employeeMethod();
			}
		}
	}
}
